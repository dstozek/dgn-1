/*
 * GHCursor.h
 *
 *  Created on: 2010-06-01
 *      Author: Tomasz Kaczmarczyk
 */

#ifndef GHCURSOR_H_
#define GHCURSOR_H_


	void GHCursor_update();
	void GHCursor_setLocation(int x, int y);

#endif /* GHCURSOR_H_ */
