/*
 * GHTime.h
 *
 *  Created on: 2010-05-09
 *      Author: Tomasz Kaczmarczyk
 */

#ifndef GHTIME_H_
#define GHTIME_H_

	void GHTime_init( void );
	void GHTime_advance( void );
	unsigned long GHTime_current( void );

#endif /* GHTIME_H_ */
